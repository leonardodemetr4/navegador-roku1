# Navegador Roku

Este projeto é o backend usado pelo app Roku para transformar páginas web em imagens que o Roku consegue exibir.

## 1. Criar o repositório no GitHub

Crie um repositório vazio, por exemplo:

`navegador-roku`

Não marque README, `.gitignore` ou licença no GitHub se você for enviar estes arquivos.

Envie para o repositório:
- `server.js`
- `package.json`
- `render.yaml`
- `.gitignore`
- `README.md`

## 2. Configurar no Render

No Render:
1. New +
2. Web Service
3. Conecte o repositório `navegador-roku`
4. Runtime: Node
5. Build Command:
   `npm install && npx playwright install chromium`
6. Start Command:
   `npm start`
7. Health Check Path:
   `/health`
8. Deploy

Depois do deploy, teste:

`https://SEU-ENDERECO.onrender.com/health`

Deve aparecer:

`{"ok":true,"service":"navegador-roku"}`

Depois teste:

`https://SEU-ENDERECO.onrender.com/browse?url=https%3A%2F%2Fwww.google.com`

O resultado deve ser uma imagem da página.

## 3. Importante

Este backend é um renderizador simples: ele captura uma página web e entrega uma imagem ao Roku. Isso não transforma o Roku em um navegador Chrome completo.

Sites que dependem de login, DRM, vídeos protegidos, pop-ups complexos ou recursos incompatíveis podem não funcionar.

Use o navegador para sites e conteúdos que você tenha direito de acessar.
